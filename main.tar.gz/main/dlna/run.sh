#!/bin/sh

gmediarender -f DLNA-$HOSTNAME "$@"