#!/bin/bash

# Set the search directory
SEARCH_DIR=/usr/lib

# Loop through each argument passed to the script
for arg in "$@"; do
  # To find file and symbolic , not include directory
  file_path=$(find "$SEARCH_DIR" -name "$arg" -type f,l)
  
  # If the file is found, print its path
  if [ -n "$file_path" ]; then
    echo "路径: $file_path"
    
    # Find all symbolic links pointing to this file
    symlink_paths=$(find "$SEARCH_DIR" -type l -lname "$arg")
    
    # Print the paths of the symbolic links
    if [ -n "$symlink_paths" ]; then
      echo "软连接：$symlink_paths"
    fi
    
    # If the file is a symbolic link, print its target path
    if [ -L "$file_path" ]; then
      target_path=$(readlink -f "$file_path")
      echo "源文件：$target_path"
    fi
  else
    echo "找不到文件: $arg"
  fi
done