#!/bin/sh

mosquitto_passwd -c -b /etc/mosquitto/pwfile $mqtt_user $mqtt_pwd && service dbus start && avahi-daemon -D --no-chroot && ( mosquitto & )

if [ -z "${GMR_ARG}" ] ; then
    
    gmediarender -f DLNA-$HOSTNAME &

else

    gmediarender -f DLNA-$HOSTNAME $GMR_ARG &

fi

while ! ( pgrep mosquitto && pgrep avahi-daemon && pgrep dbus-daemon ) > /dev/null ; do
    
    echo "Warning: Dbus or Avahi or Mqtt is not running, sleeping 5 second trying to restart them !!!"
    
    pkill dbus-daemon

    pkill kavahi-daemon

    pkill mosquitto

    mosquitto_passwd -c -b /etc/mosquitto/pwfile $mqtt_user $mqtt_pwd
    
    #service dbus start
    dbus-daemon --system --nofork --nopidfile &

    rm -rf /var/run/avahi-daemon

    avahi-daemon -D --no-chroot

    mosquitto & 

    sleep 5
    
done

echo "Dbus \ Avahi \ Mqtt are running......"

echo "Starting to run Shairport-sync for Airplay Receiver"

shairport-sync "$@"